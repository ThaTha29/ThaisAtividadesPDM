import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'fichas de alunos',
      theme: ThemeData(
        primarySwatch: Colors.pink,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Text('fichas de alunos'),
        ),
        body: FichasScreen(),
      ),
    );
  }
}

class FichasScreen extends StatelessWidget {
  var imagem1 = 'lib/imagens/img1.jpg';
  var imagem2 = 'lib/imagens/img2.jpg';
  var imagem3 = 'lib/imagens/img3.jpg';
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.all(10.0),
      children: [
        Ficha(
          nome: 'Sofia de Oliveira Silva',
          matricula: Random().nextInt(100000),
          escola: 'Escola Joaquim Nabuco',
          anoPeriodo: '2023/2',
          imagemUrl:
              imagem1,
        ),
        Ficha(
          nome: 'Maria Clara Souza',
          matricula: Random().nextInt(100000),
          escola: 'Escola Dona Antônia Valadares',
          anoPeriodo: '2023/1',
          imagemUrl:
              imagem2,
        ),
        Ficha(
          nome: 'Pedro Henrique de Oliveira',
          matricula: Random().nextInt(100000),
          escola: 'Escola São Francisco de Assis',
          anoPeriodo: '2022/2',
          imagemUrl:
              imagem3,
        ),
      ],
    );
  }
}

class Ficha extends StatelessWidget {
  final String nome;
  final int matricula;
  final String escola;
  final String anoPeriodo;
  final String imagemUrl;

  Ficha({
    required this.nome,
    required this.matricula,
    required this.escola,
    required this.anoPeriodo,
    required this.imagemUrl,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(5.0),
      ),
      margin: EdgeInsets.only(bottom: 10.0),
      padding: EdgeInsets.all(10.0),
      child: Row(
        children: [
          Container(
            width: 100.0,
            height: 100.0,
            color: Colors.grey,
            margin: EdgeInsets.only(right: 10.0),
            child: Image.asset(
              imagemUrl,
              fit: BoxFit.cover,
            ),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Nome: $nome',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                Text('Matrícula: $matricula'),
                Text('Escola: $escola'),
                Text('Ano/Período: $anoPeriodo'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}


